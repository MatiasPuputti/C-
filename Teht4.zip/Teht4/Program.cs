﻿//Matias Puputti 17.10.2019

namespace Teht4
{
    class Program
    {
        static void Main(string[] args)
        {
            Application.Run();
        }
    }
}
