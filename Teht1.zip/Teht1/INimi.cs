﻿//Matias Puputti 15/09/2019 22:36
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Olio_ohjelmoinnin_kertaus
{
    interface INimi
    {
        //Ohjeen vaatima rajapinta.
        string Nimi { get; }
    }
}
