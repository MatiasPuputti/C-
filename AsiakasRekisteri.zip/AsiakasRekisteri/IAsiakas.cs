﻿namespace AsiakasRekisteri
{
    interface IAsiakas
    {
        string AsiakasId { get; set; }
        string Nimi { get; set; }
    }
}
