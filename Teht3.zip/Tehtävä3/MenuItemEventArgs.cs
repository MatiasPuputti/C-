﻿//Matias Puputti 10.11.2019

namespace Tehtävä3
{
    class MenuItemEventArgs : System.EventArgs
    {
        public int Itemid { get; set; }

    }
}
